package com.example.demo.entity;

import lombok.Data;

@Data
public class score {
    private String StudentNo;
    private String CourseName;
    private int TeacherScore;


}
