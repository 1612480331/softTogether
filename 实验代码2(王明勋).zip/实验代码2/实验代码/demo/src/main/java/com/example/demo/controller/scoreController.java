package com.example.demo.controller;

import com.example.demo.entity.score;
import com.example.demo.entity.user;
import com.example.demo.service.scoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/score")
public class scoreController {
    @Autowired
    @Qualifier("score")
    private scoreService scoreService;

    @RequestMapping("/insertscore")
    public int insertscore(@RequestParam Map<int, String> param){
        int i=scoreService.insert(param);
        return i;
    }

    @RequestMapping("/updatescore")
    public int updatescore(@RequestParam score score){
        int i=scoreService.update(score);
        return i;
    }

    @RequestMapping("/deletescore")
    public Map<String,Object> deletescore(@RequestBody score scoreId){
        int i=scoreService.delete(scoreId);
        return i;
    }

}
