package com.example.demo.service;

import com.example.demo.entity.answerChoice;

import java.util.List;

public interface choiceAnswerService {
    public List queryByStudent(answerChoice answerChoice);
}
