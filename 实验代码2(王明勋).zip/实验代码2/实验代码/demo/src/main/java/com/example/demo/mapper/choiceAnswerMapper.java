package com.example.demo.mapper;

import com.example.demo.entity.answerChoice;

import java.util.List;

public interface choiceAnswerMapper {
    public List queryByStudent(answerChoice answerChoice);
}
