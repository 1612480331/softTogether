package com.example.demo.entity;

import lombok.Data;

@Data
public class data {
    private int InformationNo;
    private String InformationName;
    private String InformationRoad;
    private String TeacherNo;


}
