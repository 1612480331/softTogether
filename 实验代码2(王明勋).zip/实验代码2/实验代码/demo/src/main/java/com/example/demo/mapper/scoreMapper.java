package com.example.demo.mapper;

import com.example.demo.entity.score;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface scoreMapper {
    int insert(Map<int, String> param);
    int update(score score);
    int delete(score score);
}
