package com.example.demo.serviceImpl;

import com.example.demo.entity.score;
import com.example.demo.entity.user;
import com.example.demo.mapper.scoreMapper;
import com.example.demo.service.scoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service(value = "score")
public class scoreServiceImpl implements scoreService {

    @Autowired
    private scoreMapper scoreMapper;

    @Override
    public int insert(Map<int, String> param) {
        return scoreMapper.insert(param);
    }
    @Override
    public int update(score score) {
        return scoreMapper.update(score);
    }

    @Override
    public int delete(score score) {
        return scoreMapper.delete(score);
    }

}
