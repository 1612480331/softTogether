package com.example.demo.service;

import com.example.demo.entity.score;


public interface scoreService {
    public int insert(Map<int, String> param);
    public int update(score score)
    public int delete(score score);
}
